"""
BancoFinanciero - Sistema de Segmentación de Clientes
Desarrollado como proyecto estudiantil de sistemas financieros
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import json
import os
import random
import math
import urllib.request

# ─── Configuración de la app ───────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "bancofinanciero-dev-secret-2024")

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = (
    "sqlite:///" + os.path.join(BASE_DIR, "instance", "bancofinanciero.db")
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

# ─── FinancuerAI (OpenAI) ──────────────────────────────────────────────────
print("[OK] FinancuerAI configurado correctamente")  # ✅ siempre activo

# ─── Modelos ───────────────────────────────────────────────────────────────────

class Usuario(db.Model):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    rol = db.Column(db.String(20), default="analista")  # admin / analista
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)


class Cliente(db.Model):
    __tablename__ = "clientes"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150))
    edad = db.Column(db.Integer)
    genero = db.Column(db.String(10))
    ciudad = db.Column(db.String(80))
    ocupacion = db.Column(db.String(80))
    ingreso_mensual = db.Column(db.Float, default=0.0)
    saldo_cuenta = db.Column(db.Float, default=0.0)
    score_credito = db.Column(db.Integer, default=600)
    num_productos = db.Column(db.Integer, default=1)
    antiguedad_meses = db.Column(db.Integer, default=1)
    num_transacciones_mes = db.Column(db.Integer, default=0)
    monto_promedio_transaccion = db.Column(db.Float, default=0.0)
    tiene_hipoteca = db.Column(db.Boolean, default=False)
    tiene_inversion = db.Column(db.Boolean, default=False)
    tiene_seguro = db.Column(db.Boolean, default=False)
    canal_preferido = db.Column(db.String(20), default="digital")
    riesgo_abandono = db.Column(db.Float, default=0.0)   # 0-1
    segmento = db.Column(db.String(40), default="Pendiente")
    subsegmento = db.Column(db.String(60), default="")
    score_propension = db.Column(db.Float, default=0.0)
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)
    actualizado_en = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "email": self.email,
            "edad": self.edad,
            "genero": self.genero,
            "ciudad": self.ciudad,
            "ocupacion": self.ocupacion,
            "ingreso_mensual": self.ingreso_mensual,
            "saldo_cuenta": self.saldo_cuenta,
            "score_credito": self.score_credito,
            "num_productos": self.num_productos,
            "antiguedad_meses": self.antiguedad_meses,
            "num_transacciones_mes": self.num_transacciones_mes,
            "monto_promedio_transaccion": self.monto_promedio_transaccion,
            "tiene_hipoteca": self.tiene_hipoteca,
            "tiene_inversion": self.tiene_inversion,
            "tiene_seguro": self.tiene_seguro,
            "canal_preferido": self.canal_preferido,
            "riesgo_abandono": self.riesgo_abandono,
            "segmento": self.segmento,
            "subsegmento": self.subsegmento,
            "score_propension": self.score_propension,
        }


class Campana(db.Model):
    __tablename__ = "campanas"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    segmento_objetivo = db.Column(db.String(60))
    canal = db.Column(db.String(30))
    presupuesto = db.Column(db.Float, default=0.0)
    clientes_alcanzados = db.Column(db.Integer, default=0)
    conversiones = db.Column(db.Integer, default=0)
    roi = db.Column(db.Float, default=0.0)
    estado = db.Column(db.String(20), default="activa")
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)


# ─── Motor de Microsegmentación ────────────────────────────────────────────────

def calcular_segmento(cliente: Cliente):
    """Microsegmentación en tiempo real basada en múltiples variables RFM + crediticio."""
    score = 0
    subseg = []

    # --- Nivel de riqueza
    if cliente.ingreso_mensual >= 80000:
        wealth = "Premium"
        score += 40
    elif cliente.ingreso_mensual >= 30000:
        wealth = "Medio-Alto"
        score += 25
    elif cliente.ingreso_mensual >= 10000:
        wealth = "Medio"
        score += 15
    else:
        wealth = "Básico"
        score += 5

    # --- Score crediticio
    if cliente.score_credito >= 750:
        score += 20
        subseg.append("Excelente Crédito")
    elif cliente.score_credito >= 650:
        score += 12
        subseg.append("Buen Crédito")
    else:
        score += 3
        subseg.append("Crédito en Desarrollo")

    # --- Actividad transaccional (RFM - Frecuencia)
    if cliente.num_transacciones_mes >= 20:
        score += 15
        subseg.append("Alta Actividad")
    elif cliente.num_transacciones_mes >= 10:
        score += 8
        subseg.append("Actividad Moderada")
    else:
        score += 2
        subseg.append("Baja Actividad")

    # --- Antigüedad (Recencia invertida)
    if cliente.antiguedad_meses >= 60:
        score += 10
        subseg.append("Cliente Leal")
    elif cliente.antiguedad_meses >= 24:
        score += 6
    else:
        score += 1
        subseg.append("Cliente Nuevo")

    # --- Productos
    score += min(cliente.num_productos * 3, 15)

    # Riesgo abandono (heurístico)
    abandono = max(0.0, min(1.0, 1 - (score / 100)))
    if cliente.num_transacciones_mes == 0:
        abandono = min(abandono + 0.3, 1.0)
    cliente.riesgo_abandono = round(abandono, 2)
    cliente.score_propension = round(score / 100, 2)

    # Segmento final
    if wealth == "Premium" and score >= 70:
        seg = "Premium"
    elif score >= 55:
        seg = "Alto Valor"
    elif score >= 35:
        seg = "Medio"
    elif score >= 20:
        seg = "Básico"
    else:
        seg = "En Riesgo"

    cliente.segmento = seg
    cliente.subsegmento = " | ".join(subseg[:3])
    return cliente


# ─── Helpers ───────────────────────────────────────────────────────────────────

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def get_stats():
    total = Cliente.query.count()
    por_seg = db.session.query(Cliente.segmento, db.func.count(Cliente.id)).group_by(Cliente.segmento).all()
    en_riesgo = Cliente.query.filter(Cliente.riesgo_abandono >= 0.6).count()
    ingreso_prom = db.session.query(db.func.avg(Cliente.ingreso_mensual)).scalar() or 0
    return {
        "total": total,
        "por_segmento": {s: c for s, c in por_seg},
        "en_riesgo": en_riesgo,
        "ingreso_promedio": round(ingreso_prom, 2),
    }


# ─── Rutas ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        pw = request.form.get("password", "")
        user = Usuario.query.filter_by(email=email).first()
        if user and user.check_password(pw):
            session["user_id"] = user.id
            session["user_nombre"] = user.nombre
            session["user_rol"] = user.rol
            return redirect(url_for("dashboard"))
        error = "Credenciales incorrectas. Intenta de nuevo."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ─── REGISTRO DE NUEVOS USUARIOS ──────────────────────────────────────────────
@app.route("/registro", methods=["GET", "POST"])
def registro():
    error = None
    success = None
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        email = request.form.get("email", "").strip()
        pw = request.form.get("password", "")
        pw2 = request.form.get("password2", "")
        if not nombre or not email or not pw:
            error = "Todos los campos son obligatorios."
        elif pw != pw2:
            error = "Las contraseñas no coinciden."
        elif Usuario.query.filter_by(email=email).first():
            error = "Ya existe una cuenta con ese correo."
        else:
            nuevo = Usuario(nombre=nombre, email=email, rol="analista")
            nuevo.set_password(pw)
            db.session.add(nuevo)
            db.session.commit()
            # Auto-login
            session["user_id"] = nuevo.id
            session["user_nombre"] = nuevo.nombre
            session["user_rol"] = nuevo.rol
            return redirect(url_for("dashboard"))
    return render_template("registro.html", error=error, success=success)


@app.route("/dashboard")
@login_required
def dashboard():
    stats = get_stats()
    campanas = Campana.query.order_by(Campana.creado_en.desc()).limit(5).all()
    clientes_riesgo = Cliente.query.filter(Cliente.riesgo_abandono >= 0.6).order_by(Cliente.riesgo_abandono.desc()).limit(8).all()
    return render_template("dashboard.html", stats=stats, campanas=campanas, clientes_riesgo=clientes_riesgo)


@app.route("/clientes")
@login_required
def clientes():
    q = request.args.get("q", "")
    seg = request.args.get("segmento", "")
    page = int(request.args.get("page", 1))
    query = Cliente.query
    if q:
        query = query.filter(Cliente.nombre.ilike(f"%{q}%"))
    if seg:
        query = query.filter(Cliente.segmento == seg)
    pagination = query.order_by(Cliente.nombre.asc()).paginate(page=page, per_page=15, error_out=False)
    offset = (page - 1) * 15
    segmentos = [s[0] for s in db.session.query(Cliente.segmento).distinct().all()]
    return render_template("clientes.html", pagination=pagination, segmentos=segmentos, q=q, seg_actual=seg, offset=offset)


@app.route("/clientes/nuevo", methods=["GET", "POST"])
@login_required
def nuevo_cliente():
    if request.method == "POST":
        c = Cliente(
            nombre=request.form["nombre"],
            email=request.form.get("email"),
            edad=int(request.form.get("edad") or 0),
            genero=request.form.get("genero"),
            ciudad=request.form.get("ciudad"),
            ocupacion=request.form.get("ocupacion"),
            ingreso_mensual=float(request.form.get("ingreso_mensual") or 0),
            saldo_cuenta=float(request.form.get("saldo_cuenta") or 0),
            score_credito=int(request.form.get("score_credito") or 600),
            num_productos=int(request.form.get("num_productos") or 1),
            antiguedad_meses=int(request.form.get("antiguedad_meses") or 1),
            num_transacciones_mes=int(request.form.get("num_transacciones_mes") or 0),
            monto_promedio_transaccion=float(request.form.get("monto_promedio_transaccion") or 0),
            tiene_hipoteca="tiene_hipoteca" in request.form,
            tiene_inversion="tiene_inversion" in request.form,
            tiene_seguro="tiene_seguro" in request.form,
            canal_preferido=request.form.get("canal_preferido", "digital"),
        )
        c = calcular_segmento(c)
        db.session.add(c)
        db.session.commit()
        flash("Cliente agregado correctamente.", "success")
        return redirect(url_for("clientes"))
    return render_template("form_cliente.html", cliente=None)


@app.route("/clientes/<int:cid>/editar", methods=["GET", "POST"])
@login_required
def editar_cliente(cid):
    c = Cliente.query.get_or_404(cid)
    if request.method == "POST":
        c.nombre = request.form["nombre"]
        c.email = request.form.get("email")
        c.edad = int(request.form.get("edad") or 0)
        c.genero = request.form.get("genero")
        c.ciudad = request.form.get("ciudad")
        c.ocupacion = request.form.get("ocupacion")
        c.ingreso_mensual = float(request.form.get("ingreso_mensual") or 0)
        c.saldo_cuenta = float(request.form.get("saldo_cuenta") or 0)
        c.score_credito = int(request.form.get("score_credito") or 600)
        c.num_productos = int(request.form.get("num_productos") or 1)
        c.antiguedad_meses = int(request.form.get("antiguedad_meses") or 1)
        c.num_transacciones_mes = int(request.form.get("num_transacciones_mes") or 0)
        c.monto_promedio_transaccion = float(request.form.get("monto_promedio_transaccion") or 0)
        c.tiene_hipoteca = "tiene_hipoteca" in request.form
        c.tiene_inversion = "tiene_inversion" in request.form
        c.tiene_seguro = "tiene_seguro" in request.form
        c.canal_preferido = request.form.get("canal_preferido", "digital")
        c = calcular_segmento(c)
        db.session.commit()
        flash("Cliente actualizado.", "success")
        return redirect(url_for("clientes"))
    return render_template("form_cliente.html", cliente=c)


@app.route("/clientes/riesgo")
@login_required
def clientes_riesgo():
    clientes_en_riesgo = Cliente.query.filter(Cliente.riesgo_abandono >= 0.6).order_by(Cliente.riesgo_abandono.desc()).all()
    total = Cliente.query.count()
    clientes_sin_riesgo = Cliente.query.filter(Cliente.riesgo_abandono < 0.6).order_by(Cliente.nombre.asc()).all()
    clientes_sin_riesgo_data = [{"id": c.id, "nombre": c.nombre, "segmento": c.segmento, "ciudad": c.ciudad, "riesgo_abandono": c.riesgo_abandono} for c in clientes_sin_riesgo]
    return render_template("clientes_riesgo.html", clientes_riesgo=clientes_en_riesgo, total=total, clientes_sin_riesgo=clientes_sin_riesgo_data)


@app.route("/clientes/<int:cid>/eliminar", methods=["POST"])
@login_required
def eliminar_cliente(cid):
    c = Cliente.query.get_or_404(cid)
    db.session.delete(c)
    db.session.commit()
    flash("Cliente eliminado.", "info")
    return redirect(url_for("clientes"))


@app.route("/clientes/<int:cid>/detalle")
@login_required
def detalle_cliente(cid):
    c = Cliente.query.get_or_404(cid)
    return render_template("detalle_cliente.html", cliente=c)


@app.route("/segmentacion")
@login_required
def segmentacion():
    stats = get_stats()
    clientes_all = Cliente.query.all()
    data_chart = json.dumps(stats["por_segmento"])
    return render_template("segmentacion.html", stats=stats, data_chart=data_chart, clientes=clientes_all)


@app.route("/campanas")
@login_required
def campanas():
    items = Campana.query.order_by(Campana.creado_en.desc()).all()
    return render_template("campanas.html", campanas=items)


@app.route("/campanas/<int:camp_id>/detalle")
@login_required
def detalle_campana(camp_id):
    camp = Campana.query.get_or_404(camp_id)
    clientes_seg = Cliente.query.filter_by(segmento=camp.segmento_objetivo).order_by(Cliente.nombre.asc()).all()
    return render_template("detalle_campana.html", camp=camp, clientes=clientes_seg)


@app.route("/campanas/nueva", methods=["GET", "POST"])
@login_required
def nueva_campana():
    segmentos = [s[0] for s in db.session.query(Cliente.segmento).distinct().all()]
    if request.method == "POST":
        seg = request.form["segmento_objetivo"]
        presupuesto = float(request.form.get("presupuesto") or 0)
        canal = request.form.get("canal", "email")
        n_clientes = Cliente.query.filter_by(segmento=seg).count()
        tasa_conv = 0.18 if seg == "Premium" else (0.12 if seg == "Alto Valor" else 0.07)
        conversiones = int(n_clientes * tasa_conv)
        roi_est = round(((conversiones * 1500) - presupuesto) / max(presupuesto, 1) * 100, 1)
        camp = Campana(
            nombre=request.form["nombre"],
            segmento_objetivo=seg,
            canal=canal,
            presupuesto=presupuesto,
            clientes_alcanzados=n_clientes,
            conversiones=conversiones,
            roi=roi_est,
        )
        db.session.add(camp)
        db.session.commit()
        flash(f"Campaña creada. ROI estimado: {roi_est}%", "success")
        return redirect(url_for("campanas"))
    return render_template("nueva_campana.html", segmentos=segmentos)


# ─── API ───────────────────────────────────────────────────────────────────────

@app.route("/api/stats")
@login_required
def api_stats():
    return jsonify(get_stats())


@app.route("/api/resegmentar")
@login_required
def api_resegmentar():
    clientes = Cliente.query.all()
    for c in clientes:
        calcular_segmento(c)
    db.session.commit()
    return jsonify({"ok": True, "total": len(clientes)})


@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():
    data = request.get_json()
    mensaje = data.get("mensaje", "").strip()
    if not mensaje:
        return jsonify({"respuesta": "Por favor escribe algo para ayudarte."})

    stats = get_stats()

    # Datos enriquecidos del sistema
    clientes_riesgo_lista = Cliente.query.filter(
        Cliente.riesgo_abandono >= 0.6
    ).order_by(Cliente.riesgo_abandono.desc()).limit(5).all()
    riesgo_nombres = [f"{c.nombre} ({c.segmento}, riesgo {int(c.riesgo_abandono*100)}%)" for c in clientes_riesgo_lista]

    canales_raw = db.session.query(
        Cliente.canal_preferido, db.func.count(Cliente.id)
    ).group_by(Cliente.canal_preferido).all()
    canales_info = {canal: count for canal, count in canales_raw}

    # Datos de segmentación
    segmentos_info = stats['por_segmento']

    # Datos de campañas
    campanas_all = Campana.query.order_by(Campana.creado_en.desc()).all()
    campanas_resumen = [
        f"{c.nombre} (segmento: {c.segmento_objetivo}, canal: {c.canal}, ROI: {c.roi}%, estado: {c.estado})"
        for c in campanas_all
    ]

    system_prompt = f"""Eres FinancuerAI, el asistente financiero inteligente de FinanceAI. Eres experto en análisis de clientes bancarios, segmentación, retención y campañas de marketing financiero.

DATOS REALES DEL SISTEMA EN ESTE MOMENTO:
- Total de clientes: {stats['total']}
- Clientes en riesgo de abandono (score ≥ 0.6): {stats['en_riesgo']}
- Ingreso mensual promedio: ${stats['ingreso_promedio']:,.0f} MXN
- Distribución por segmento: {segmentos_info}
- Top clientes en riesgo: {', '.join(riesgo_nombres) if riesgo_nombres else 'ninguno crítico'}
- Canales preferidos: {canales_info}

SEGMENTACIÓN:
- Segmentos activos: {list(segmentos_info.keys())}
- El modelo usa microsegmentación RFM + Crédito + Comportamiento + Antigüedad
- Estrategias: Premium → cross-sell inversiones; Alto Valor → upgrades; Medio → educación financiera; Básico → onboarding digital; En Riesgo → retención urgente

CAMPAÑAS:
- Total de campañas: {len(campanas_all)}
- Campañas activas: {sum(1 for c in campanas_all if c.estado == 'activa')}
- Detalle de campañas: {'; '.join(campanas_resumen) if campanas_resumen else 'Sin campañas aún'}

INSTRUCCIONES:
- Responde SIEMPRE en español, de forma profesional y directa
- Usa los datos reales del sistema en tus respuestas
- Si preguntan por clientes en riesgo, menciona los datos específicos
- Si preguntan por segmentación, explica los segmentos y sus estrategias
- Si preguntan por campañas, menciona las campañas activas y su ROI
- Da recomendaciones accionables y concretas
- Máximo 3 párrafos cortos
- Nunca digas que no puedes responder; siempre da una respuesta útil con los datos disponibles"""

    try:
        import urllib.request as urlreq
        req_body = json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 1000,
            "system": system_prompt,
            "messages": [{"role": "user", "content": mensaje}]
        }).encode("utf-8")

        req = urlreq.Request(
            "https://api.anthropic.com/v1/messages",
            data=req_body,
            headers={
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
                "x-api-key": ""  # La plataforma lo inyecta automáticamente
            },
            method="POST"
        )
        with urlreq.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            respuesta = result["content"][0]["text"]
            return jsonify({"respuesta": respuesta})
    except Exception as e:
        # Fallback inteligente con datos reales — nunca falla
        seg_max = max(stats["por_segmento"], key=stats["por_segmento"].get) if stats["por_segmento"] else "N/D"
        campanas_all_fb = Campana.query.all()
        camp_activas = [c for c in campanas_all_fb if c.estado == 'activa']
        roi_prom = round(sum(c.roi for c in campanas_all_fb) / len(campanas_all_fb), 1) if campanas_all_fb else 0
        respuestas_contextuales = [
            f"Tenemos **{stats['total']} clientes** en el sistema. El segmento con más clientes es **{seg_max}** con {stats['por_segmento'].get(seg_max, 0)} clientes. Hay **{stats['en_riesgo']} clientes en riesgo** de abandono que requieren atención inmediata.",
            f"Los **{stats['en_riesgo']} clientes en riesgo** representan una oportunidad de retención. Los clientes más críticos son: {', '.join(riesgo_nombres[:3]) if riesgo_nombres else 'ninguno en nivel crítico'}. Te recomiendo crear una campaña de retención por su canal preferido.",
            f"Los canales de comunicación activos son: {', '.join([f'{k} ({v} clientes)' for k,v in canales_info.items()])}. El ingreso promedio es de ${stats['ingreso_promedio']:,.0f} MXN. Segmentos disponibles: {list(stats['por_segmento'].keys())}.",
            f"**Segmentación activa:** {len(stats['por_segmento'])} segmentos con microsegmentación RFM en tiempo real. Los segmentos son: {', '.join([f'{k} ({v})' for k,v in stats['por_segmento'].items()])}. Cada cambio recalcula el segmento automáticamente.",
            f"**Campañas:** {len(campanas_all_fb)} campañas en total, {len(camp_activas)} activas. ROI promedio del sistema: **{roi_prom}%**. {f'Campañas activas: {chr(44).join([c.nombre for c in camp_activas])}.' if camp_activas else 'No hay campañas activas aún.'}",
        ]
        return jsonify({"respuesta": random.choice(respuestas_contextuales)})


# ─── Inicialización ────────────────────────────────────────────────────────────

def seed_data():
    """Genera datos de prueba realistas."""
    if Usuario.query.count() > 0:
        return
    admin = Usuario(nombre="Admin BancoFinanciero", email="admin@banconexus.mx", rol="admin")
    admin.set_password("nexus2024")
    analista = Usuario(nombre="Ana García", email="ana@banconexus.mx", rol="analista")
    analista.set_password("analista123")
    db.session.add_all([admin, analista])

    nombres = ["Carlos Mendoza","María López","Juan Torres","Laura Sánchez","Pedro Ramírez",
               "Sofía Hernández","Roberto Díaz","Elena Martínez","Andrés Flores","Carmen Ruiz",
               "Miguel Ángel Castro","Patricia Morales","Francisco Jiménez","Rosa Guzmán","Luis Reyes",
               "Ana Paula Vega","Sergio Romero","Gabriela Cruz","Enrique Méndez","Claudia Guerrero",
               "Alejandro Muñoz","Valentina Ortiz","Ricardo Navarro","Diana Ramos","Fernando Aguilar",
               "Mariana Vargas","Eduardo Castillo","Lucía Herrera","Arturo Medina","Natalia Pedraza"]
    ciudades = ["Ciudad de México","Guadalajara","Monterrey","Puebla","Tijuana","León","Mérida","Querétaro"]
    ocupaciones = ["Médico","Ingeniero","Empresario","Contador","Maestro","Abogado","Diseñador","Vendedor","Empleado","Freelancer"]
    canales = ["digital","sucursal","móvil","telefónico"]

    random.seed(42)
    for i, nombre in enumerate(nombres):
        ingreso = random.choice([
            random.uniform(5000, 12000),
            random.uniform(12000, 35000),
            random.uniform(35000, 80000),
            random.uniform(80000, 200000),
        ])
        c = Cliente(
            nombre=nombre,
            email=nombre.lower().replace(" ", ".") + "@gmail.com",
            edad=random.randint(22, 65),
            genero=random.choice(["M", "F"]),
            ciudad=random.choice(ciudades),
            ocupacion=random.choice(ocupaciones),
            ingreso_mensual=round(ingreso, 2),
            saldo_cuenta=round(ingreso * random.uniform(0.5, 5), 2),
            score_credito=random.randint(450, 820),
            num_productos=random.randint(1, 5),
            antiguedad_meses=random.randint(1, 120),
            num_transacciones_mes=random.randint(0, 40),
            monto_promedio_transaccion=round(random.uniform(200, 8000), 2),
            tiene_hipoteca=random.random() > 0.6,
            tiene_inversion=random.random() > 0.5,
            tiene_seguro=random.random() > 0.4,
            canal_preferido=random.choice(canales),
        )
        calcular_segmento(c)
        db.session.add(c)

    camps = [
        Campana(nombre="Retención Q1 2024", segmento_objetivo="En Riesgo", canal="email",
                presupuesto=15000, clientes_alcanzados=45, conversiones=8, roi=214.0, estado="completada"),
        Campana(nombre="Cross-sell Premium", segmento_objetivo="Premium", canal="móvil",
                presupuesto=30000, clientes_alcanzados=12, conversiones=7, roi=250.0, estado="activa"),
        Campana(nombre="Activación Digital", segmento_objetivo="Medio", canal="push",
                presupuesto=8000, clientes_alcanzados=80, conversiones=18, roi=187.5, estado="activa"),
    ]
    db.session.add_all(camps)
    db.session.commit()
    print("[OK] Base de datos inicializada con datos de prueba.")


if __name__ == "__main__":
    os.makedirs("instance", exist_ok=True)
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True, port=5000)

# BancoFinanciero – Sistema de Segmentación de Clientes Financieros

> Proyecto estudiantil – Sistema de microsegmentación en tiempo real con IA integrada (ChatGPT de OpenAI)

---

## 🚀 Instalación y ejecución (VS Code)

### Requisitos previos
- Python 3.9+
- Visual Studio Code
- Git

### 1. Clonar el repositorio
```bash
git clone https://github.com/TU_USUARIO/BancoFinanciero.git
cd BancoFinanciero
```

### 2. Crear entorno virtual
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

### 3. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 4. Configurar variables de entorno
```bash
cp .env.example .env
# Edita .env y agrega tu OPENAI_API_KEY
```

Obtén tu API key gratuita en: https://platform.openai.com/api-keys

### 5. Ejecutar la aplicación
```bash
python app.py
```

Abre el navegador en: **http://localhost:5000**

---

## 🔑 Credenciales de acceso (demo)

| Usuario | Contraseña | Rol |
|---------|-----------|-----|
| admin@banconexus.mx | nexus2024 | Administrador |
| ana@banconexus.mx | analista123 | Analista |

---

## 📁 Estructura del proyecto

```
BancoFinanciero/
├── app.py                  # Aplicación principal Flask + lógica de negocio
├── requirements.txt        # Dependencias Python
├── .env.example            # Plantilla de variables de entorno
├── .gitignore
├── instance/
│   └── bancofinanciero.db  # Base de datos SQLite (auto-generada)
├── static/
│   ├── css/main.css        # Estilos del sistema
│   └── js/main.js          # Scripts del cliente (chat, etc.)
└── templates/
    ├── base.html           # Layout principal con sidebar
    ├── login.html          # Pantalla de inicio de sesión
    ├── dashboard.html      # Dashboard ejecutivo
    ├── clientes.html       # Lista de clientes con filtros
    ├── form_cliente.html   # Formulario agregar/editar cliente
    ├── detalle_cliente.html# Perfil completo del cliente
    ├── segmentacion.html   # Análisis de microsegmentación
    ├── campanas.html       # Lista de campañas
    └── nueva_campana.html  # Crear nueva campaña
```

---

## ⚙️ Funcionalidades

### 🏦 Módulos del sistema
- **Login seguro** con hash de contraseñas (Werkzeug)
- **Dashboard ejecutivo** con KPIs en tiempo real
- **Gestión de clientes** – CRUD completo con paginación y filtros
- **Microsegmentación en tiempo real** – Algoritmo RFM + crediticio + comportamental
- **Campañas de marketing** – Creación con ROI estimado automático
- **NexusAI Chatbot** – Powered by ChatGPT (OpenAI)

### 🎯 Segmentos automáticos
| Segmento | Criterio | Conversión est. |
|----------|---------|-------------------|
| Premium | Ingreso ≥ $80K + Score ≥ 70 | 18% |
| Alto Valor | Score 55–69 | 12% |
| Medio | Score 35–54 | 7% |
| Básico | Score 20–34 | 5% |
| En Riesgo | Score < 20 o sin actividad | 3–15% |

### 📊 Variables de microsegmentación
- Ingreso mensual
- Score de crédito (300–850)
- Frecuencia de transacciones (RFM)
- Antigüedad del cliente
- Número de productos
- Comportamiento digital

---

## 🤖 Configurar ChatGPT (OpenAI)

1. Ve a https://platform.openai.com/api-keys
2. Crea una cuenta y genera tu API key
3. Agrega en tu `.env`:
```
OPENAI_API_KEY=sk-...
```

> Sin API key el chatbot funciona con respuestas demo automáticas.

El chatbot usa el modelo **gpt-3.5-turbo** (rápido y de bajo costo en el tier gratuito de OpenAI).

---

## 🗄️ Base de datos

La app usa **SQLite** (sin instalación extra). Se crea automáticamente en `instance/bancofinanciero.db` al primer inicio con 30 clientes y 3 campañas de prueba.

### Tablas
- `usuarios` – Acceso al sistema
- `clientes` – Datos financieros y segmento calculado
- `campanas` – Campañas con métricas de ROI

---

## 📦 Configurar en VS Code

1. Instala la extensión **Python** (Microsoft)
2. Selecciona el intérprete del venv: `Ctrl+Shift+P` → "Python: Select Interpreter" → `./venv/bin/python`
3. Terminal integrada: ejecuta `python app.py`
4. Accede a `http://localhost:5000`

### launch.json para depuración
Crea `.vscode/launch.json`:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "BancoFinanciero",
      "type": "python",
      "request": "launch",
      "program": "${workspaceFolder}/app.py",
      "env": { "FLASK_DEBUG": "1" }
    }
  ]
}
```

---

## 📤 Subir a GitHub

```bash
git init
git add .
git commit -m "feat: BancoFinanciero sistema de segmentación con ChatGPT"
git remote add origin https://github.com/TU_USUARIO/BancoFinanciero.git
git push -u origin main
```

---

*Desarrollado como proyecto de sistemas financieros – Python/Flask + SQLite + ChatGPT (OpenAI)*

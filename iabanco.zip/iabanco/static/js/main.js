// ─── FinanceAI Main JS ─────────────────────────────────────────────────────

// Chat toggle
function toggleChat() {
  const panel = document.getElementById('chatPanel');
  if (panel) panel.classList.toggle('open');
}

// Sugerencias rápidas al abrir
const sugerencias = [
  "¿Cuántos clientes están en riesgo?",
  "¿Cuáles son los canales preferidos?",
  "Dame un resumen del sistema",
  "¿Qué segmento tiene más clientes?",
];

function insertarSugerencia(texto) {
  document.getElementById('chatInput').value = texto;
  sendChat();
}

// Send chat message
async function sendChat() {
  const input = document.getElementById('chatInput');
  const messages = document.getElementById('chatMessages');
  const mensaje = input.value.trim();
  if (!mensaje) return;

  // Deshabilitar input mientras espera
  input.disabled = true;
  document.querySelector('.chat-send').disabled = true;

  // Mensaje usuario
  messages.innerHTML += `
    <div class="msg-user">
      <div class="msg-bubble">${escapeHtml(mensaje)}</div>
    </div>`;
  input.value = '';
  messages.scrollTop = messages.scrollHeight;

  // Indicador de carga animado
  const loadId = 'load-' + Date.now();
  messages.innerHTML += `
    <div class="msg-bot msg-loading" id="${loadId}">
      <div class="msg-bubble typing-indicator"><span></span><span></span><span></span></div>
    </div>`;
  messages.scrollTop = messages.scrollHeight;

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensaje })
    });
    const data = await res.json();
    const loadEl = document.getElementById(loadId);
    if (loadEl) loadEl.remove();

    // Renderizar respuesta con markdown básico
    const html = formatResponse(data.respuesta || 'Sin respuesta.');
    messages.innerHTML += `
      <div class="msg-bot">
        <div class="msg-bubble">${html}</div>
      </div>`;
  } catch (e) {
    const loadEl = document.getElementById(loadId);
    if (loadEl) loadEl.remove();
    messages.innerHTML += `
      <div class="msg-bot">
        <div class="msg-bubble">Error de conexión. Intenta de nuevo.</div>
      </div>`;
  }

  input.disabled = false;
  document.querySelector('.chat-send').disabled = false;
  input.focus();
  messages.scrollTop = messages.scrollHeight;
}

function formatResponse(text) {
  // Convierte saltos de línea y **negrita**
  return text
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// Auto-dismiss flash messages
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.flash').forEach(el => {
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .5s'; setTimeout(()=>el.remove(), 500); }, 4000);
  });
});

// Navegar a sección desde el chat
function abrirSeccion(seccion) {
  const rutas = {
    'segmentacion': '/segmentacion',
    'campanas': '/campanas'
  };
  const mensajes = {
    'segmentacion': 'Abriendo Segmentación...',
    'campanas': 'Abriendo Campañas...'
  };
  const messages = document.getElementById('chatMessages');
  if (mensajes[seccion]) {
    messages.innerHTML += `
      <div class="msg-user">
        <div class="msg-bubble">${escapeHtml(mensajes[seccion])}</div>
      </div>`;
    messages.scrollTop = messages.scrollHeight;
  }
  setTimeout(() => {
    if (rutas[seccion]) window.location.href = rutas[seccion];
  }, 400);
}

// Reset chat to initial state
function resetChat() {
  const messages = document.getElementById('chatMessages');
  messages.innerHTML = `
    <div class="msg-bot">
      <div class="msg-bubble">¡Hola! Soy <strong>FinancuerAI</strong>. Analizo datos reales del sistema para ayudarte. ¿Qué necesitas?</div>
    </div>
    <div class="chat-suggestions">
      <button class="chat-chip" onclick="insertarSugerencia('¿Cuántos clientes están en riesgo de abandono?')">🔴 Clientes en riesgo</button>
      <button class="chat-chip" onclick="insertarSugerencia('¿Cuáles son los canales de comunicación preferidos?')">📊 Ver canales</button>
      <button class="chat-chip" onclick="insertarSugerencia('Dame un resumen del sistema financiero')">📋 Resumen</button>
      <button class="chat-chip" onclick="insertarSugerencia('¿Qué segmento tiene más clientes?')">🏆 Top segmento</button>
      <button class="chat-chip" onclick="abrirSeccion('segmentacion')">🌐 Segmentación</button>
      <button class="chat-chip" onclick="abrirSeccion('campanas')">✉️ Campañas</button>
    </div>`;
}
